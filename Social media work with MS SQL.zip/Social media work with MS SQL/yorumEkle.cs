﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace sosyal_medya
{
    public partial class yorumEkle : Form
    {
        public yorumEkle()
        {
            InitializeComponent();
        }

        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-UL9P68G;Initial Catalog=sqlodev;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text == "")
            {
                MessageBox.Show("lütfen boş alan bırakmayınız...");
            }

            else
            {
                baglanti.Open();

                string baslık;
                string yorum;
                string isim;

                baslık = sabit1.baslık;
                yorum = richTextBox1.Text;
                isim = sabit1.ad;

                SqlCommand eklemek = new SqlCommand("insert into TblYorum(başlık,yorum,kullanıcı_ad) values('" + baslık + "','" + yorum + "','" + isim + "')", baglanti);
                eklemek.ExecuteNonQuery();
                MessageBox.Show("yorum eklendi");
                
                this.Close();
            }

                baglanti.Close();
            }

        private void yorumEkle_Load(object sender, EventArgs e)
        {

        }
    }
}

