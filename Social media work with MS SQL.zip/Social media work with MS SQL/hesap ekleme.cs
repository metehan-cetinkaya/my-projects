﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace sosyal_medya
{
    public partial class hesap_ekleme : Form
    {
        public hesap_ekleme()
        {
            InitializeComponent();
        }
        
        private void hesap_ekleme_Load(object sender, EventArgs e)
        {

        }

        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-UL9P68G;Initial Catalog=sqlodev;Integrated Security=True");

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("lütfen boş alan bırakmayınız...");
            }

            else
            {
                baglanti.Open();

                string user;
                string password;
                string mail;
                int yetki;

                user = textBox1.Text;
                password = textBox2.Text;
                mail = textBox3.Text;
                yetki = 2;

                SqlCommand komut = new SqlCommand("select * from TblKullanıcı where kullanıcı_ad='" + user + "'", baglanti);
                SqlDataReader oku = komut.ExecuteReader();

                if (oku.Read())
                {
                    MessageBox.Show("bu kullanıcı adı kullanılıyor lütfen başka kullanıcı adı seçin");
                }
                else
                {
                    oku.Close();
                    SqlCommand ekle = new SqlCommand("insert into TblKullanıcı(kullanıcı_ad,kullanıcı_şifre,kullanıcı_mail,yetki_id) values('" + user + "','" + password + "','" + mail + "','" + yetki + "')", baglanti);
                    ekle.ExecuteNonQuery();
                    MessageBox.Show("kayıt oldunuz...");
                    sabit1.ad = textBox1.Text;
                    sabit1.a = 1;

                    this.Close();
                }

                baglanti.Close();
            }


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
