using System.Data.SqlClient;

namespace sosyal_medya
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-UL9P68G;Initial Catalog=sqlodev;Integrated Security=True");

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("l�tfen bo� alan b�rakmay�n�z...");
            }

            else
            {
                baglanti.Open();

                string user;
                string password;

                user = textBox1.Text;
                password = textBox2.Text;

                
               
                SqlCommand komut = new SqlCommand("select * from TblKullan�c� where kullan�c�_ad='" + user + "' and kullan�c�_�ifre='" + password + "'", baglanti);
                SqlDataReader oku = komut.ExecuteReader();

                if (oku.Read())
                {
                    
                    sabit1.ad = textBox1.Text;
                    sabit1.a = 1;
                    
                    this.Close();
                }
                else
                {
                    MessageBox.Show("kullan�c� ad� veya �ifre hatal�");
                }

                baglanti.Close();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            hesap_ekleme gecis = new hesap_ekleme();
            gecis.Show();
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
  
}

