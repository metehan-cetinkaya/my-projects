﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace sosyal_medya
{
    public partial class YazıEkle : Form
    {
        public YazıEkle()
        {
            InitializeComponent();
        }

        private void YazıEkle_Load(object sender, EventArgs e)
        {

        }

        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-UL9P68G;Initial Catalog=sqlodev;Integrated Security=True");

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || richTextBox1.Text == "")
            {
                MessageBox.Show("lütfen boş alan bırakmayınız...");
            }

            else
            {
                baglanti.Open();

                string baslık;
                string yazi;
                string isim;
                
                

                baslık = textBox1.Text;
                yazi = richTextBox1.Text;
                isim = sabit1.ad;
                


                SqlCommand komut = new SqlCommand("select * from TblYazı where başlık='" + baslık + "'", baglanti);
                SqlDataReader oku = komut.ExecuteReader();

                if (oku.Read())
                {
                    MessageBox.Show("bu başlık kullanılıyor lütfen başka başlık seçin");
                }
                else
                {
                    oku.Close();
                    SqlCommand eklemek = new SqlCommand("insert into TblYazı(başlık,yazı,kullanıcı_ad) values('" + baslık + "','" + yazi + "','" + isim + "')", baglanti);
                    eklemek.ExecuteNonQuery();
                    MessageBox.Show("yazı eklendi");

                    this.Close();
                }

                baglanti.Close();
            }
        }
    }
}
