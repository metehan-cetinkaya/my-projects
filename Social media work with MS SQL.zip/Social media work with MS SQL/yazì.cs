﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace sosyal_medya
{
    public partial class yazı : Form
    {
        public yazı()
        {
            InitializeComponent();
        }

        SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-UL9P68G;Initial Catalog=sqlodev;Integrated Security=True");

        private void göster()
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * From TblYorum where başlık like '%" + sabit1.baslık + "%'", baglanti);
            SqlDataReader oku = komut.ExecuteReader();

            DataTable tablo = new DataTable();

            tablo.Columns.Add("kullanıcı adı", typeof(string));
            tablo.Columns.Add("yorum", typeof(string));

            while (oku.Read())
            {
                string kullanıcı = oku["kullanıcı_ad"].ToString();
                string yaz = oku["yorum"].ToString();
                tablo.Rows.Add(kullanıcı, yaz);

                dataGridView1.DataSource = tablo;
            }

            baglanti.Close();
        }
        


        private void yazı_Load(object sender, EventArgs e)
        {
            timer1.Start();
            label3.Text = sabit1.yazar;
            label2.Text = sabit1.baslık;
            richTextBox1.Text = sabit1.yazı;
            göster();
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            yorumEkle gecis = new yorumEkle();
            gecis.Show();
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            richTextBox2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            göster();
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (sabit1.a == 1)
            {
                button2.Visible = true;
                
                timer1.Stop();

            }
        }
    }
}
