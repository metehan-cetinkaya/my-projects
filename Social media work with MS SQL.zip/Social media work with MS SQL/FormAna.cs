﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace sosyal_medya
{
    public partial class FormAna : Form
    {
        public FormAna()
        {
            InitializeComponent();
        }

    SqlConnection baglanti = new SqlConnection("Data Source=DESKTOP-UL9P68G;Initial Catalog=sqlodev;Integrated Security=True");

        private void VerileriGöster()
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * From TblYazı", baglanti);
            SqlDataReader oku = komut.ExecuteReader();

            DataTable tablo = new DataTable();

            tablo.Columns.Add("yazar", typeof(string));
            tablo.Columns.Add("başlık", typeof(string));
            tablo.Columns.Add("yazı", typeof(string));

            while (oku.Read())
            {
                string kullanıcı = oku["kullanıcı_ad"].ToString();
                string başlık = oku["başlık"].ToString();
                string yaz = oku["yazı"].ToString();
                tablo.Rows.Add(kullanıcı, başlık, yaz);

                dataGridView1.DataSource = tablo;
            }

            baglanti.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            Form1 gecis = new Form1();
            gecis.Show();
     
        }

        private void FormAna_Load(object sender, EventArgs e)
        {
            VerileriGöster();
            dataGridView1.Rows[0].Cells[0].Selected = false;

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            YazıEkle gecis = new YazıEkle();
            gecis.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            VerileriGöster();
            dataGridView1.Rows[0].Cells[0].Selected = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            SqlCommand komut = new SqlCommand("select * From TblYazı where başlık + kullanıcı_ad like '%" + textBox1.Text + "%'", baglanti);
            SqlDataReader oku = komut.ExecuteReader();

            DataTable tablo = new DataTable();

            tablo.Columns.Add("yazar", typeof(string));
            tablo.Columns.Add("başlık", typeof(string));
            tablo.Columns.Add("yazı", typeof(string));

            while (oku.Read())
            {
                string kullanıcı = oku["kullanıcı_ad"].ToString();
                string başlık = oku["başlık"].ToString();
                string yaz = oku["yazı"].ToString();
                tablo.Rows.Add(kullanıcı, başlık, yaz);

                dataGridView1.DataSource = tablo;
            }
            
            baglanti.Close();
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            sabit1.yazı = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            sabit1.baslık = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            sabit1.yazar = dataGridView1.CurrentRow.Cells[0].Value.ToString();
        
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (sabit1.a == 1)
            {
                btnyazı.Visible = true;
                btngiriş.Visible = false;
                button1.Visible = true;
                label1.Text = sabit1.ad;
                label1.Visible = true;
                pictureBox1.Visible = true;
                pictureBox2.Visible = true;
                timer1.Stop();

            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            btnyazı.Visible = false;
            btngiriş.Visible = true;
            button1.Visible = false;
            label1.Visible = false;
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            sabit1.a = 0;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            yazı gecis = new yazı();
            gecis.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
