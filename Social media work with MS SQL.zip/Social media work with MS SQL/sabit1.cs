﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace sosyal_medya
{
    internal class sabit1
    {

        public static string ad;
        public static int a;
        public static string baslık;
        public static string yazı;
        public static string yazar;
        public static string yorum;
    }          

    
}
